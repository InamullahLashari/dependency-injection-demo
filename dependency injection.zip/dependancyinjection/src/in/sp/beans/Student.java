package in.sp.beans;

import in.sp.adds.address;

public class Student {
    private String name;
    private int rollno;
    private address address; // Correct type for the address field

    // Getter and Setter for 'name'
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    // Getter and Setter for 'rollno'
    public int getRollno() {
        return rollno;
    }

    public void setRollno(int rollno) {
        this.rollno = rollno;
    }

    // Getter and Setter for 'address'
    public address getAddress() {
        return address;
    }

    public void setAddress(address address) {
        this.address = address;
    }

    // Display Method
    public void display() {
        System.out.println("Name = " + name);
        System.out.println("Roll No = " + rollno);
        System.out.println("Address = " + address);
    }
}
