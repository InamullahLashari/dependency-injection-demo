package in.sp.adds;

public class address {
    private int street;
    private int pincode;

    // Setters for street and pincode
    public void setStreet(int street) {
        this.street = street;
    }

    public void setPincode(int pincode) {
        this.pincode = pincode;
    }

    @Override
    public String toString() {
        return "Street: " + street + ", Pincode: " + pincode;
    }
}
